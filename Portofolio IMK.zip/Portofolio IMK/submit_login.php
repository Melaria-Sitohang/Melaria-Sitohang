<?php
// Ganti dengan informasi login yang sebenarnya
$valid_username = "user";
$valid_password = "pass";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username == $valid_username && $password == $valid_password) {
        // Jika login berhasil
        header("Location: index.html");
    } else {
        // Jika login gagal
        echo "Username atau password salah!";
    }
}
?>
